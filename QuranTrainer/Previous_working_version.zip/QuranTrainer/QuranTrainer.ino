// Offline Quran memorization: ESP32-S3 N16R8, SPI ILI9341, XPT2046 touch.
// Set SCREEN_ST7789 to 1 only if your seller confirms an ST7789 panel.
#define SCREEN_ST7789 0
#include <Arduino.h>
#include <SPI.h>
#include <Preferences.h>
#include <Adafruit_GFX.h>
#if SCREEN_ST7789
#include <Adafruit_ST7789.h>
#else
#include <Adafruit_ILI9341.h>
#endif
#include <XPT2046_Touchscreen.h>
#include <math.h>
#include "quran_data.h"

constexpr int SCK_PIN=12, MISO_PIN=13, MOSI_PIN=11;
constexpr int TFT_CS=10, TFT_DC=9, TFT_RST=8, TOUCH_CS=7;
constexpr int W=320, H=240, ROWS=3, MENU_ROWS=5;
constexpr uint16_t BG=0x08C4, PANEL=0x1947, WHITE=0xFFFE, GOLD=0xDD88, DIM=0x8C71;
enum Label { L_SURAH,L_RESUME,L_PREV,L_NEXT,L_HIDE,L_SHOW,L_BACK,L_HIDDEN,
 L_SHOW_VERSE,L_MORE,L_QURAN,L_REVIEW,L_START,L_WORD,L_REVEAL,L_RESET,L_MENU,L_DONE,L_PART };
struct Token { uint16_t word, ayah; bool marker; };
struct Bookmark { uint32_t magic; uint16_t last; uint16_t pages[114]; };
struct Calibration { uint32_t magic; float ax,bx,cx,ay,by,cy; };
void label(int id,int x,int baseline,int width,uint16_t color=WHITE);
void button(int x,int y,int w,int h,int id,uint16_t color=WHITE);

#if SCREEN_ST7789
Adafruit_ST7789 tft(TFT_CS,TFT_DC,TFT_RST);
#else
Adafruit_ILI9341 tft(TFT_CS,TFT_DC,TFT_RST);
#endif
XPT2046_Touchscreen touch(TOUCH_CS);
GFXcanvas16 canvas(W,H);
Preferences prefs;
Bookmark saved{};
Calibration cal{};
Token *tokens=nullptr;
uint16_t *lineStart=nullptr;
int tokenCount=0, lineCount=0, pages=0, surah=0, page=0, menuPage=0;
int revealedUntil=0;
bool reading=false, practice=false, held=false, bookmark=false;
unsigned long lastTap=0;
constexpr uint32_t BOOK_MAGIC=0x51545232, CAL_MAGIC=0x43414C32;

void flush() { tft.drawRGBBitmap(0,0,canvas.getBuffer(),W,H); }
void latin(int x,int y,const String &s,uint16_t color=WHITE,int size=1) {
 canvas.setTextSize(size); canvas.setTextColor(color); canvas.setCursor(x,y); canvas.print(s);
}
void word(uint16_t id,int x,int baseline,uint16_t color) {
 const QWord &w=qWords[id];
 for(uint32_t i=w.first;i<w.first+w.count;++i) {
  const QRun &r=qRuns[i]; const QGlyph &g=qGlyphs[r.glyph];
  if(g.w && g.h) canvas.drawBitmap(x+w.bearing+r.x+g.x,baseline+r.y+g.y,
    qBitmap+g.offset,g.w,g.h,color);
 }
}
void sequence(const uint16_t *ids,int count,int right,int baseline,uint16_t color) {
 for(int i=0;i<count;++i) { right-=qWords[ids[i]].width; word(ids[i],right,baseline,color); right-=6; }
}
void label(int id,int x,int baseline,int width,uint16_t color) {
 const QLabel &l=qLabels[id]; const uint16_t *ids=qLabelWords+l.first;
 int len=0; for(int i=0;i<l.count;++i) len+=qWords[ids[i]].width+(i?6:0);
 sequence(ids,l.count,x+(width+len)/2,baseline,color);
}
void button(int x,int y,int w,int h,int id,uint16_t color) {
 canvas.fillRoundRect(x,y,w,h,5,PANEL);
 const QLabel &l=qLabels[id]; int top=0,bottom=0;
 for(int k=0;k<l.count;++k) {
  const QWord &qw=qWords[qLabelWords[l.first+k]];
  for(uint32_t i=qw.first;i<qw.first+qw.count;++i) {
   const QRun &r=qRuns[i]; const QGlyph &g=qGlyphs[r.glyph];
   top=min(top,int(r.y)+g.y); bottom=max(bottom,int(r.y)+g.y+g.h);
  }
 }
 label(id,x,y+(h-(bottom-top))/2-top,w,color);
}
int widthOf(int index) { return tokens[index].marker?28:qWords[tokens[index].word].width; }
int pageStart() { return lineStart[page*ROWS]; }
int pageEnd() { return lineStart[min(lineCount,(page+1)*ROWS)]; }
void saveBookmark() {
 saved.magic=BOOK_MAGIC; saved.last=surah; saved.pages[surah]=page;
 if(prefs.putBytes("bookmark",&saved,sizeof(saved))!=sizeof(saved)) Serial.println("Bookmark write failed");
 bookmark=true;
}
void buildLayout() {
 free(tokens); free(lineStart); tokens=nullptr; lineStart=nullptr;
 const QSurah &s=qSurahs[surah]; tokenCount=0;
 for(int a=0;a<s.count;++a) tokenCount+=qAyahs[s.first+a].count+1;
 tokens=(Token*)malloc(tokenCount*sizeof(Token));
 lineStart=(uint16_t*)malloc((tokenCount+1)*sizeof(uint16_t));
 if(!tokens || !lineStart) { Serial.println("Layout allocation failed"); while(true) delay(100); }
 int index=0;
 for(int a=0;a<s.count;++a) {
  const QAyah &v=qAyahs[s.first+a];
  for(int k=0;k<v.count;++k) tokens[index++]={qSequence[v.first+k],uint16_t(a+1),false};
  tokens[index++]={0,uint16_t(a+1),true};
 }
 lineCount=1; lineStart[0]=0; int used=0;
 for(int i=0;i<tokenCount;++i) {
  int ww=widthOf(i);
  if(used && used+6+ww>292) { lineStart[lineCount++]=i; used=0; }
  used+=(used?6:0)+ww;
 }
 lineStart[lineCount]=tokenCount; pages=(lineCount+ROWS-1)/ROWS;
 page=constrain(page,0,pages-1);
}
void drawMenu() {
 reading=false; canvas.fillScreen(BG); label(L_SURAH,220,29,90,GOLD);
 if(bookmark) button(7,3,145,32,L_RESUME,GOLD);
 for(int row=0;row<MENU_ROWS;++row) {
  int s=menuPage*MENU_ROWS+row; if(s>=Q_SURAH_COUNT) break;
  int y=42+31*row; canvas.fillRoundRect(7,y,306,28,4,PANEL);
  const QSurah &q=qSurahs[s]; sequence(qNameWords+q.nameFirst,q.nameCount,301,y+22,WHITE);
  latin(16,y+9,String(s+1),GOLD);
 }
 button(7,203,90,34,L_PREV); button(223,203,90,34,L_NEXT);
 latin(137,216,String(menuPage+1)+"/"+String((Q_SURAH_COUNT+MENU_ROWS-1)/MENU_ROWS),DIM);
 flush();
}
void drawPage() {
 reading=true; canvas.fillScreen(BG);
 const QSurah &s=qSurahs[surah]; sequence(qNameWords+s.nameFirst,s.nameCount,309,28,GOLD);
 latin(8,9,String(page+1)+"/"+String(pages),DIM);
 latin(8,23,String(tokens[pageStart()].ayah)+"-"+String(tokens[pageEnd()-1].ayah),DIM);
 canvas.drawFastHLine(8,39,304,PANEL);
 for(int row=0;row<ROWS;++row) {
  int line=page*ROWS+row; if(line>=lineCount) break;
  int right=306, baseline=75+row*36;
  for(int i=lineStart[line];i<lineStart[line+1];++i) {
   int ww=widthOf(i); right-=ww;
   bool visible=!practice || i<revealedUntil;
   if(visible) {
    if(tokens[i].marker) {
     canvas.drawCircle(right+14,baseline-8,13,GOLD);
     String n=String(tokens[i].ayah); latin(right+14-n.length()*3,baseline-11,n,GOLD);
    } else word(tokens[i].word,right,baseline,WHITE);
   } else if(!tokens[i].marker) {
    canvas.fillRoundRect(right,baseline-11,ww,5,2,PANEL);
   }
   right-=6;
  }
 }
 button(4,168,80,34,practice?L_RESET:L_START,GOLD);
 button(88,168,128,34,L_WORD,practice?WHITE:DIM);
 button(220,168,96,34,L_REVEAL,practice?WHITE:DIM);
 button(4,204,100,34,L_PREV); button(110,204,100,34,L_NEXT);
 button(216,204,100,34,L_MENU);
 flush();
}
void openSurah(int s) {
 surah=s; page=saved.pages[s]; practice=false; buildLayout(); saveBookmark(); drawPage();
}
void navigate(int delta) {
 int target=constrain(page+delta,0,pages-1); if(target==page) return;
 int oldReveal=revealedUntil; page=target;
 if(practice) revealedUntil=(delta>0)?max(pageStart(),oldReveal):pageStart();
 saveBookmark(); drawPage();
}
void startPractice() { practice=true; revealedUntil=pageStart(); drawPage(); }
void revealWord() {
 if(!practice || revealedUntil>=pageEnd()) return;
 while(revealedUntil<tokenCount && tokens[revealedUntil].marker) ++revealedUntil;
 if(revealedUntil<pageEnd()) ++revealedUntil;
 while(revealedUntil<tokenCount && tokens[revealedUntil].marker) ++revealedUntil;
 drawPage();
}
void revealAyah() {
 if(!practice || revealedUntil>=pageEnd()) return;
 while(revealedUntil<tokenCount && tokens[revealedUntil].marker) ++revealedUntil;
 if(revealedUntil>=pageEnd()) { drawPage(); return; }
 int a=tokens[revealedUntil].ayah;
 // Reveal the whole ayah, including its continuation on subsequent pages.
 while(revealedUntil<tokenCount && tokens[revealedUntil].ayah==a) ++revealedUntil;
 drawPage();
}
void handleTap(int x,int y) {
 if(!reading) {
  if(y<37 && x<160 && bookmark) { openSurah(saved.last); return; }
  if(y>=42 && y<197) {
   int row=(y-42)/31;
   if((y-42)%31<28 && menuPage*MENU_ROWS+row<Q_SURAH_COUNT) openSurah(menuPage*MENU_ROWS+row);
  } else if(y>=203) {
   if(x<104 && menuPage>0) --menuPage;
   else if(x>216 && (menuPage+1)*MENU_ROWS<Q_SURAH_COUNT) ++menuPage;
   drawMenu();
  }
 } else {
  if(y>=168 && y<202) {
   if(x<85) startPractice(); else if(x<217) revealWord(); else revealAyah();
  } else if(y>=204) {
   if(x<105) navigate(-1); else if(x<211) navigate(1);
   else { menuPage=surah/MENU_ROWS; drawMenu(); }
  }
 }
}
void waitRelease() { while(touch.touched()) { touch.getPoint(); delay(15); } delay(180); }
TS_Point calibrationSample(int x,int y,int number) {
 waitRelease(); canvas.fillScreen(BG);
 latin(30,90,"Touch calibration "+String(number)+"/4",WHITE,2);
 latin(30,120,"Tap and hold the cross",DIM);
 canvas.drawFastHLine(x-10,y,21,GOLD); canvas.drawFastVLine(x,y-10,21,GOLD); flush();
 int count=0; long sx=0,sy=0;
 while(count<20) {
  if(touch.touched()) {
   TS_Point p=touch.getPoint();
   if(p.z>250) { sx+=p.x; sy+=p.y; ++count; }
  } else { count=0; sx=sy=0; }
  delay(10);
 }
 TS_Point result(sx/count,sy/count,0); waitRelease(); return result;
}
void calibrate() {
 // Three non-collinear points fit affine coordinates; fourth validates the fit.
 const int px[4]={20,299,20,299}, py[4]={20,20,219,219};
 while(true) {
  TS_Point r[4]; for(int i=0;i<4;++i) r[i]=calibrationSample(px[i],py[i],i+1);
  float u1=r[1].x-r[0].x,v1=r[1].y-r[0].y;
  float u2=r[2].x-r[0].x,v2=r[2].y-r[0].y;
  float determinant=u1*v2-u2*v1;
  if(fabsf(determinant)<100000) { Serial.println("Calibration degenerate; retry"); continue; }
  cal.ax=279*v2/determinant; cal.bx=-279*u2/determinant;
  cal.ay=-199*v1/determinant; cal.by=199*u1/determinant;
  cal.cx=20-cal.ax*r[0].x-cal.bx*r[0].y;
  cal.cy=20-cal.ay*r[0].x-cal.by*r[0].y;
  float checkX=cal.ax*r[3].x+cal.bx*r[3].y+cal.cx;
  float checkY=cal.ay*r[3].x+cal.by*r[3].y+cal.cy;
  if(fabsf(checkX-299)>22 || fabsf(checkY-219)>22) {
   Serial.println("Calibration check failed; repeat all four crosses"); continue;
  }
  cal.magic=CAL_MAGIC; prefs.putBytes("cal",&cal,sizeof(cal)); break;
 }
 held=false;
}
bool getTouch(int &x,int &y) {
 if(!touch.touched()) { held=false; return false; }
 TS_Point p=touch.getPoint();
 if(p.z<250 || held || millis()-lastTap<160) return false;
 x=lroundf(cal.ax*p.x+cal.bx*p.y+cal.cx);
 y=lroundf(cal.ay*p.x+cal.by*p.y+cal.cy);
 held=true; lastTap=millis();
 if(x<0 || x>=W || y<0 || y>=H) return false;
 return true;
}
void serialControl() {
 if(!Serial.available()) return;
 char c=Serial.read();
 if(c=='k') { calibrate(); if(reading) drawPage(); else drawMenu(); }
 if(c=='b') drawMenu();
 if(c=='c' && bookmark) openSurah(saved.last);
 if(reading) {
  if(c=='n') navigate(1); if(c=='p') navigate(-1);
  if(c=='h') startPractice(); if(c=='w') revealWord(); if(c=='a') revealAyah();
 }
}
void setup() {
 Serial.begin(115200);
 if(!canvas.getBuffer()) { Serial.println("Framebuffer allocation failed"); while(true) delay(100); }
 pinMode(TFT_CS,OUTPUT); digitalWrite(TFT_CS,HIGH);
 pinMode(TOUCH_CS,OUTPUT); digitalWrite(TOUCH_CS,HIGH);
 SPI.begin(SCK_PIN,MISO_PIN,MOSI_PIN);
 #if SCREEN_ST7789
 tft.init(240,320);
#else
 tft.begin(20000000);
#endif
 tft.setRotation(1);
 touch.begin(); touch.setRotation(0);
 prefs.begin("quran-trainer",false);
 if(prefs.getBytesLength("bookmark")==sizeof(saved)) prefs.getBytes("bookmark",&saved,sizeof(saved));
 if(saved.magic==BOOK_MAGIC && saved.last<Q_SURAH_COUNT) bookmark=true;
 else memset(&saved,0,sizeof(saved));
 if(prefs.getBytesLength("cal")==sizeof(cal)) prefs.getBytes("cal",&cal,sizeof(cal));
 if(cal.magic!=CAL_MAGIC || !isfinite(cal.ax) || !isfinite(cal.by)) calibrate();
 Serial.println("Commands: k calibrate, b menu, c resume, n next, p previous, h start, w word, a ayah");
 // Always start at the menu; Resume opens the saved surah and page.
 drawMenu();
}
void loop() { int x,y; if(getTouch(x,y)) handleTap(x,y); serialControl(); delay(10); }
